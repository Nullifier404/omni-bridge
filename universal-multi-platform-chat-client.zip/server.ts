import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import crypto from "crypto";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Gemini API
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
} else {
  console.warn("WARNING: GEMINI_API_KEY environment variable is not defined.");
}

// Memory database for stateless Cloud Run (resilient via Client Sync)
interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  status: 'online' | 'offline' | 'away';
  isAi?: boolean;
  platform?: string;
  ipHash?: string;
}

interface Message {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: number;
  status: 'sent' | 'delivered' | 'read';
  platform: 'local' | 'whatsapp' | 'telegram' | 'messenger' | 'viber';
}

const users = new Map<string, UserProfile>();
const messages: Message[] = [];

// Seed the default global nodes/bots
const seedBots: UserProfile[] = [
  {
    id: "user_omni_ai",
    name: "Omni AI Assistant",
    avatar: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&h=100&fit=crop",
    bio: "Official OmniBridge System Intelligence. Ask me anything! ⚡",
    status: "online",
    isAi: true
  },
  {
    id: "user_seed_tokyo",
    name: "Kaito Takahashi 🇯🇵",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    bio: "Active on Tokyo Node • Software Craftsman 🌸",
    status: "online",
    isAi: true
  },
  {
    id: "user_seed_berlin",
    name: "Elena Rostova 🇩🇪",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    bio: "Active on Berlin Node • UI/UX Alchemist 🎨",
    status: "online",
    isAi: true
  },
  {
    id: "user_seed_london",
    name: "Marcus Vance 🇬🇧",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    bio: "Active on London Node • Dist Sys Arch ☕",
    status: "online",
    isAi: true
  }
];

seedBots.forEach(bot => {
  users.set(bot.id, bot);
});

// Pre-populate some general messages for new rooms
const defaultRooms = [
  { id: "global", name: "🌍 Global Lobby", desc: "Chat with anyone visiting worldwide!" },
  { id: "tech", name: "💻 Tech & Dev Space", desc: "Talk coding, design, and tech." },
  { id: "lounge", name: "☕ Chill Lounge", desc: "Grab a tea and relax with other visitors." }
];

const defaultMessages: Message[] = [
  {
    id: "msg_init_1",
    roomId: "global",
    senderId: "user_seed_tokyo",
    senderName: "Kaito Takahashi 🇯🇵",
    senderAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    text: "Welcome to OmniBridge Chat! This platform has direct links to active developer nodes worldwide. Everything is ultra-fast and direct.",
    timestamp: Date.now() - 3600000 * 2,
    status: "read",
    platform: "local"
  },
  {
    id: "msg_init_2",
    roomId: "global",
    senderId: "user_seed_berlin",
    senderName: "Elena Rostova 🇩🇪",
    senderAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    text: "Exactly. No logins, completely private node tunnels. Try clicking our cards under Direct Messages to start a private chat with any node!",
    timestamp: Date.now() - 3600000 * 1,
    status: "read",
    platform: "local"
  },
  {
    id: "msg_init_3",
    roomId: "tech",
    senderId: "user_seed_london",
    senderName: "Marcus Vance 🇬🇧",
    senderAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    text: "Checking in from London. Ask me or Omni AI anything directly!",
    timestamp: Date.now() - 3600000 * 1.5,
    status: "read",
    platform: "local"
  }
];

messages.push(...defaultMessages);

// Helper to clean up messages to prevent memory issues
function addMessage(msg: Message) {
  messages.push(msg);
  // Keep only last 1000 messages in server memory
  if (messages.length > 1000) {
    messages.shift();
  }
}

// 1. IP hashing to auto-create unique, highly private IDs
app.get("/api/user/me", (req, res) => {
  // Extract client IP address securely
  const forwarded = req.headers["x-forwarded-for"];
  const ip = typeof forwarded === "string" 
    ? forwarded.split(",")[0].trim() 
    : req.socket.remoteAddress || "127.0.0.1";

  // Create a clean SHA-256 hash of the IP for maximum privacy
  const hash = crypto.createHash("sha256").update(ip).digest("hex");
  const userId = `user_${hash.substring(0, 10)}`;

  // Generate a fun animal-based placeholder nickname if they aren't registered yet
  const animals = ["Phoenix", "Cheetah", "Panda", "Fox", "Falcon", "Otter", "Koala", "Leopard", "Dolphin", "Badger"];
  const colors = ["Golden", "Crimson", "Azure", "Emerald", "Mystic", "Silver", "Neon", "Sunset", "Cosmic", "Amber"];
  
  if (!users.has(userId)) {
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    const randomAnimal = animals[Math.floor(Math.random() * animals.length)];
    const name = `${randomColor} ${randomAnimal}`;
    
    // Select an elegant placeholder geometric avatar
    const avatars = [
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
      "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop",
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
      "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&h=100&fit=crop"
    ];
    const avatar = avatars[Math.floor(Math.random() * avatars.length)];

    users.set(userId, {
      id: userId,
      name: name,
      avatar: avatar,
      bio: "Active on local node • Secure Citizen 🛡️",
      status: "online",
      ipHash: hash
    });
  }

  res.json({
    userId,
    profile: users.get(userId),
    ipHidden: true
  });
});

// 2. Sync endpoint: allow client to sync custom profile
app.post("/api/user/sync", (req, res) => {
  const { profile } = req.body;
  if (!profile || !profile.id) {
    return res.status(400).json({ error: "Invalid profile data" });
  }

  const userId = profile.id;
  // Preserve original IP hash and isAi tag if present
  const original = users.get(userId);
  users.set(userId, {
    ...original,
    ...profile,
    status: "online"
  });

  res.json({ success: true, userCount: users.size });
});

// 3. Rooms listing
app.get("/api/rooms", (req, res) => {
  res.json(defaultRooms);
});

// 4. Fetch messages with offset filtering for fast incremental updates
app.get("/api/messages", (req, res) => {
  const { roomId, since } = req.query;
  if (!roomId) {
    return res.status(400).json({ error: "roomId parameter is required" });
  }

  let filtered = messages.filter(m => m.roomId === roomId);
  if (since) {
    const sinceTime = parseInt(since as string, 10);
    if (!isNaN(sinceTime)) {
      filtered = filtered.filter(m => m.timestamp > sinceTime);
    }
  }

  res.json(filtered);
});

// 5. Submit messages
app.post("/api/messages", async (req, res) => {
  const { roomId, senderId, senderName, senderAvatar, text, platform } = req.body;
  
  if (!roomId || !senderId || !text) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const newMessage: Message = {
    id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    roomId,
    senderId,
    senderName: senderName || "Anonymous User",
    senderAvatar: senderAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
    text,
    timestamp: Date.now(),
    status: "delivered",
    platform: platform || "local"
  };

  addMessage(newMessage);

  // Trigger AI reply if this is a Direct Message with an AI/Seed Bot
  if (roomId.startsWith("dm_")) {
    const parts = roomId.split("_");
    const otherUserId = parts.find(p => p !== "dm" && p !== senderId);
    
    if (otherUserId && users.has(otherUserId)) {
      const contactProfile = users.get(otherUserId);
      if (contactProfile && contactProfile.isAi) {
        res.json({ status: "queued", message: newMessage });

        setTimeout(async () => {
          try {
            const contactId = contactProfile.id;
            const contactName = contactProfile.name;
            const contactAvatar = contactProfile.avatar;

            if (!ai) {
              const staticReplies = [
                "Awesome! Got your message on the secure OmniBridge network. Latency is fantastic.",
                "Hey there! Love chat nodes like this. How are things on your side?",
                "That's sweet. I'm actively monitoring this node. Everything runs super fast!",
                "Hello secure visitor! Feel free to ask me anything or try out public rooms."
              ];
              const staticReply = staticReplies[Math.floor(Math.random() * staticReplies.length)];
              const aiMessage: Message = {
                id: `msg_ai_${Date.now()}`,
                roomId,
                senderId: contactId,
                senderName: contactName,
                senderAvatar: contactAvatar,
                text: staticReply,
                timestamp: Date.now(),
                status: "read",
                platform: "local"
              };
              addMessage(aiMessage);
              return;
            }

            // Get recent conversation history for context
            const recentMessages = messages
              .filter(m => m.roomId === roomId)
              .slice(-12)
              .map(m => `${m.senderName}: ${m.text}`)
              .join("\n");

            let prompt = "";
            let systemInstruction = "";

            if (contactId === "user_omni_ai") {
              systemInstruction = "You are the Omni AI Assistant, a helpful, brilliant, and extremely fast AI built right into the OmniBridge platform. You answer user questions concisely with clean formatting, emojis, and professional composure.";
              prompt = `The user is chatting with you, the Omni AI Assistant, on the OmniBridge Chat platform.
Reply to their message naturally and guide them on how to use the site:
- Explain that OmniBridge auto-hashes client IP addresses to create instantly secure, anonymous chat accounts.
- Emojis are welcome.
- Keep it highly professional and friendly.

Here is the conversation history:
${recentMessages}

Please write your reply now:`;
            } else {
              systemInstruction = `You are playing the role of ${contactName}, an expert developer or designer who is currently chatting on the OmniBridge platform. You are connected to a specific global node as described in your status: "${contactProfile.bio}".`;
              prompt = `The user is chatting with you, ${contactName}, directly on the OmniBridge platform.
Please reply to their latest message naturally and conversationally, as a friendly tech enthusiast from your city:
- Keep the messages relatively brief, friendly, and authentic.
- Talk about coding, design, or local node vibes in Tokyo, Berlin, or London depending on your profile.
- Do not mention that you are an AI or a language model. Chat like a real person on a professional developer chatroom.

Here is the conversation history:
${recentMessages}

Please write your reply now:`;
            }

            const response = await ai.models.generateContent({
              model: "gemini-3.5-flash",
              contents: prompt,
              config: {
                temperature: 0.8,
                systemInstruction: systemInstruction
              }
            });

            const replyText = response.text || "Hello there!";
            const aiMessage: Message = {
              id: `msg_ai_${Date.now()}`,
              roomId,
              senderId: contactId,
              senderName: contactName,
              senderAvatar: contactAvatar,
              text: replyText.trim(),
              timestamp: Date.now(),
              status: "read",
              platform: "local"
            };
            addMessage(aiMessage);

          } catch (err) {
            console.error("Error generating Gemini DM reply:", err);
            const aiMessage: Message = {
              id: `msg_ai_err_${Date.now()}`,
              roomId,
              senderId: contactProfile.id,
              senderName: contactProfile.name,
              senderAvatar: contactProfile.avatar,
              text: "My node connection is slightly laggy, but I'm here! 👍",
              timestamp: Date.now(),
              status: "read",
              platform: "local"
            };
            addMessage(aiMessage);
          }
        }, 1500);
        return;
      }
    }
  }

  res.json({ status: "success", message: newMessage });
});

// 6. Active users listing
app.get("/api/users/online", (req, res) => {
  res.json(Array.from(users.values()));
});


// ----------------- VITE MIDDLEWARE SETUP -----------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
