import { useState, useEffect, useRef } from "react";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import { UserProfile, Message, Room } from "./types";
import { Globe2 } from "lucide-react";

export default function App() {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [activeRoomId, setActiveRoomId] = useState<string>("global");
  const [messages, setMessages] = useState<Message[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<UserProfile[]>([]);
  
  const [isAiTyping, setIsAiTyping] = useState(false);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const lastMsgTimestampRef = useRef<number>(0);
  const pollTimerRef = useRef<NodeJS.Timeout | null>(null);
  const syncedRef = useRef<boolean>(false);

  // Sound generator
  const playNotificationSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // Sweet snappy beep
      gainNode.gain.setValueAtTime(0.06, audioCtx.currentTime);
      oscillator.start();

      oscillator.frequency.setValueAtTime(1100, audioCtx.currentTime + 0.08);
      gainNode.gain.setValueAtTime(0.06, audioCtx.currentTime + 0.08);
      
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
      oscillator.stop(audioCtx.currentTime + 0.3);
    } catch (err) {
      // Bypass browser audio context autoplay blocks gracefully
    }
  };

  // 1. Initial Load & IP-Based Identity Creation
  useEffect(() => {
    async function loadIdentity() {
      try {
        setLoading(true);

        // Fetch IP-hashed identity from backend
        const res = await fetch("/api/user/me");
        if (!res.ok) throw new Error("Failed to auto-authenticate with secure nodes");
        const data = await res.json();
        
        // Merge with client-side localStorage customized overrides (name, avatar, bio)
        const cachedProfileStr = localStorage.getItem("omnibridge_cached_profile");
        let activeProfile: UserProfile = {
          id: data.userId,
          name: data.profile.name,
          avatar: data.profile.avatar,
          bio: data.profile.bio,
          status: "online"
        };

        if (cachedProfileStr) {
          try {
            const cachedProfile = JSON.parse(cachedProfileStr);
            if (cachedProfile && cachedProfile.id === data.userId) {
              activeProfile = { ...activeProfile, ...cachedProfile };
            }
          } catch (e) {
            console.error("Error parsing cached profile", e);
          }
        }

        setUserProfile(activeProfile);

        // Fetch official predefined channels
        const roomsRes = await fetch("/api/rooms");
        if (roomsRes.ok) {
          const roomsData = await roomsRes.json();
          setRooms(roomsData);
        }

        // Run primary synchronization with server
        await syncWithServer(activeProfile);
        setLoading(false);
      } catch (err: any) {
        console.error("Identity load error", err);
        setErrorMsg(err.message || "An unexpected secure network error occurred.");
        setLoading(false);
      }
    }

    loadIdentity();
  }, []);

  // 2. Synchronize current settings to stateless backend
  const syncWithServer = async (profile: UserProfile) => {
    try {
      await fetch("/api/user/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile })
      });
      syncedRef.current = true;
    } catch (e) {
      console.error("Failed server synchronization", e);
    }
  };

  // 3. Online Users list polling (updates every 4 seconds)
  useEffect(() => {
    if (!userProfile) return;

    async function fetchOnlineUsers() {
      try {
        const res = await fetch("/api/users/online");
        if (res.ok) {
          const data: UserProfile[] = await res.json();
          // Filter out the current user, keep others
          setOnlineUsers(data.filter(u => u.id !== userProfile.id));
        }
      } catch (e) {
        console.error("Failed to fetch online users", e);
      }
    }

    fetchOnlineUsers();
    const interval = setInterval(fetchOnlineUsers, 4000);
    return () => clearInterval(interval);
  }, [userProfile]);

  // 4. Fast incremental message polling loop (Speed like WhatsApp!)
  useEffect(() => {
    if (!userProfile) return;

    // Reset timestamp pointer on room change
    lastMsgTimestampRef.current = 0;
    setMessages([]);
    setIsAiTyping(false);

    async function poll() {
      try {
        const url = `/api/messages?roomId=${activeRoomId}&since=${lastMsgTimestampRef.current}`;
        const res = await fetch(url);
        if (!res.ok) return;
        const newMsgs: Message[] = await res.json();

        if (newMsgs.length > 0) {
          // Play sound if there is a message from another user
          const hasIncoming = newMsgs.some(m => m.senderId !== userProfile.id);
          if (hasIncoming) {
            playNotificationSound();
          }

          // Update message state
          setMessages(prev => {
            // Filter duplicates & merge
            const existingIds = new Set(prev.map(m => m.id));
            const uniqueIncoming = newMsgs.filter(m => !existingIds.has(m.id));
            if (uniqueIncoming.length === 0) return prev;
            return [...prev, ...uniqueIncoming];
          });

          // Update latest timestamp
          const maxTime = Math.max(...newMsgs.map(m => m.timestamp));
          if (maxTime > lastMsgTimestampRef.current) {
            lastMsgTimestampRef.current = maxTime;
          }

          // If we received an AI reply on DM, stop typing state
          const hasAiReply = newMsgs.some(m => m.senderId !== userProfile.id && m.roomId.startsWith("dm_"));
          if (hasAiReply) {
            setIsAiTyping(false);
          }
        }
      } catch (err) {
        console.error("Polling error", err);
      }
    }

    // Run first fetch immediately
    poll();

    // Loop every 1.5 seconds for WhatsApp-like speedy sync
    pollTimerRef.current = setInterval(poll, 1500);

    return () => {
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
      }
    };
  }, [activeRoomId, userProfile]);

  // 5. Update Profile
  const handleUpdateProfile = async (name: string, avatar: string, bio: string) => {
    if (!userProfile) return;

    const updated = { ...userProfile, name, avatar, bio };
    setUserProfile(updated);
    localStorage.setItem("omnibridge_cached_profile", JSON.stringify(updated));

    // Instantly sync settings with backend
    await syncWithServer(updated);
  };

  // 6. Submit a message
  const handleSendMessage = async (text: string, imageUrl?: string) => {
    if (!userProfile) return;

    const finalMessageText = imageUrl ? `[IMG]${imageUrl}` : text;
    const isDm = activeRoomId.startsWith("dm_");

    const payload = {
      roomId: activeRoomId,
      senderId: userProfile.id,
      senderName: userProfile.name,
      senderAvatar: userProfile.avatar,
      text: finalMessageText,
      platform: "local"
    };

    // Optimistic local state update for instant WhatsApp-like UI response
    const optimisticMessage: Message = {
      id: `optimistic_${Date.now()}`,
      roomId: activeRoomId,
      senderId: userProfile.id,
      senderName: userProfile.name,
      senderAvatar: userProfile.avatar,
      text: finalMessageText,
      timestamp: Date.now(),
      status: "sent",
      platform: "local"
    };

    setMessages(prev => [...prev, optimisticMessage]);

    // Show typing status immediately if target is an AI bot
    if (isDm) {
      const otherUserId = activeRoomId.split("_").find(p => p !== "dm" && p !== userProfile.id);
      const otherUser = otherUserId ? onlineUsers.find(u => u.id === otherUserId) : null;
      if (otherUser?.isAi) {
        setIsAiTyping(true);
      }
    }

    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      
      if (!res.ok) {
        // Fallback or retry state can be implemented if required
        setMessages(prev => prev.map(m => m.id === optimisticMessage.id ? { ...m, status: "sent" } : m));
      }
    } catch (e) {
      console.error("Send message failed", e);
    }
  };

  // Helper variables to locate correct active info
  const isDm = activeRoomId.startsWith("dm_");
  let activeRoomName = "";
  let activeRoomDesc = "";
  let activeDmUser: UserProfile | null = null;

  if (isDm) {
    const otherUserId = activeRoomId.split("_").find(p => p !== "dm" && p !== userProfile?.id);
    const otherUser = onlineUsers.find(u => u.id === otherUserId);
    if (otherUser) {
      activeDmUser = otherUser;
      activeRoomName = otherUser.name;
      activeRoomDesc = otherUser.bio || "Active on Secure Node Tunnel";
    } else {
      activeRoomName = "Encrypted Connection";
      activeRoomDesc = "Secure point-to-point private bridge channel";
    }
  } else {
    const room = rooms.find(r => r.id === activeRoomId);
    if (room) {
      activeRoomName = room.name;
      activeRoomDesc = room.desc;
    }
  }

  if (loading) {
    return (
      <div className="h-screen bg-[#050508] flex flex-col items-center justify-center font-sans p-6 text-slate-100">
        <div className="flex flex-col items-center space-y-4 max-w-sm text-center">
          <Globe2 size={44} className="text-cyan-400 animate-spin-slow mb-2" />
          <h2 className="text-xl font-bold tracking-tight">Linking Secure Node Tunnel...</h2>
          <p className="text-xs text-slate-400">
            Hashing client node IP. Your connection remains completely anonymous, encrypted, and secure. No registration required.
          </p>
          <div className="w-32 h-1 bg-white/5 rounded-full overflow-hidden">
            <div className="h-full bg-cyan-400 animate-loading-bar rounded-full" />
          </div>
        </div>
      </div>
    );
  }

  if (errorMsg) {
    return (
      <div className="h-screen bg-[#050508] flex flex-col items-center justify-center font-sans p-6 text-slate-100">
        <div className="border border-red-950 bg-red-950/10 rounded-2xl p-6 text-center max-w-sm shadow-xl space-y-4">
          <span className="text-4xl text-red-500">⚠️</span>
          <h2 className="text-lg font-bold">Secure Tunnel Connection Failed</h2>
          <p className="text-xs text-slate-400 leading-relaxed">{errorMsg}</p>
          <button 
            id="retry-connect-btn"
            onClick={() => window.location.reload()} 
            className="bg-red-600 hover:bg-red-500 text-white font-semibold text-xs px-4 py-2 rounded-lg cursor-pointer transition-colors"
          >
            Retry Tunnel Connection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-[#050508] flex font-sans overflow-hidden">
      
      {/* Sidebar Panel */}
      <Sidebar
        userProfile={userProfile}
        onUpdateProfile={handleUpdateProfile}
        rooms={rooms}
        activeRoomId={activeRoomId}
        onSelectRoom={setActiveRoomId}
        onlineUsers={onlineUsers}
      />

      {/* Main Chat Area */}
      <ChatWindow
        userProfile={userProfile}
        activeRoomId={activeRoomId}
        roomName={activeRoomName}
        roomDesc={activeRoomDesc}
        isDm={isDm}
        activeDmUser={activeDmUser}
        messages={messages}
        onSendMessage={handleSendMessage}
        isAiTyping={isAiTyping}
      />

    </div>
  );
}
