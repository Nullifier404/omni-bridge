export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  status: 'online' | 'offline' | 'away';
  isAi?: boolean;
  platform?: string;
}

export interface Message {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: number;
  status: 'sent' | 'delivered' | 'read';
  platform: 'local' | 'whatsapp' | 'telegram' | 'messenger' | 'viber';
}

export interface Room {
  id: string;
  name: string;
  desc: string;
}

export interface AiContact {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  platform: 'whatsapp' | 'telegram' | 'messenger' | 'viber';
  phoneNumber?: string;
  username?: string;
}
