import { X } from "lucide-react";
import React, { useState } from "react";

interface AvatarPickerProps {
  currentAvatar: string;
  onSelect: (url: string) => void;
  onClose: () => void;
}

const PRESET_AVATARS = [
  // Elegant diverse portraits from Unsplash
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop",
  "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&h=150&fit=crop",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop",
  "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&h=150&fit=crop",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop",
  // Stylish geometric patterns
  "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&h=150&fit=crop",
  "https://images.unsplash.com/photo-1574169208507-84376144848b?w=150&h=150&fit=crop",
  "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=150&h=150&fit=crop",
  "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=150&h=150&fit=crop"
];

export default function AvatarPicker({ currentAvatar, onSelect, onClose }: AvatarPickerProps) {
  const [customUrl, setCustomUrl] = useState("");

  const handleSubmitCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (customUrl.trim()) {
      onSelect(customUrl.trim());
      onClose();
    }
  };

  return (
    <div id="avatar-picker-backdrop" className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fade-in">
      <div id="avatar-picker-modal" className="bg-[#08090C] border border-white/10 rounded-2xl w-full max-w-md p-6 shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-white">Select Profile Picture</h3>
          <button 
            id="close-avatar-picker-btn"
            onClick={onClose} 
            className="text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        <div className="grid grid-cols-5 gap-3 mb-6">
          {PRESET_AVATARS.map((url, idx) => (
            <button
              id={`preset-avatar-btn-${idx}`}
              key={idx}
              onClick={() => {
                onSelect(url);
                onClose();
              }}
              className={`relative rounded-full overflow-hidden aspect-square border-2 cursor-pointer transition-all hover:scale-105 hover:shadow-lg ${
                currentAvatar === url ? "border-cyan-500 scale-105" : "border-transparent"
              }`}
            >
              <img src={url} alt={`Preset ${idx}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </button>
          ))}
        </div>

        <div className="border-t border-white/10 pt-5">
          <h4 className="text-sm font-medium text-slate-300 mb-3">Or use a custom image URL:</h4>
          <form onSubmit={handleSubmitCustom} className="flex gap-2">
            <input
              id="custom-avatar-url-input"
              type="url"
              placeholder="https://example.com/avatar.jpg"
              value={customUrl}
              onChange={(e) => setCustomUrl(e.target.value)}
              className="flex-1 bg-[#050508] border border-white/10 text-slate-100 text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            <button
              id="submit-custom-avatar-btn"
              type="submit"
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-sm rounded-lg px-4 py-2 transition-colors cursor-pointer"
            >
              Apply
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
