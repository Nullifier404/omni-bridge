import React, { useState, useEffect, useRef } from "react";
import { Message, UserProfile } from "../types";
import { Send, Image, Check, CheckCheck } from "lucide-react";

interface ChatWindowProps {
  userProfile: UserProfile | null;
  activeRoomId: string;
  roomName: string;
  roomDesc: string;
  isDm: boolean;
  activeDmUser: UserProfile | null;
  messages: Message[];
  onSendMessage: (text: string, imageUrl?: string) => void;
  isAiTyping: boolean;
}

export default function ChatWindow({
  userProfile,
  activeRoomId,
  roomName,
  roomDesc,
  isDm,
  activeDmUser,
  messages,
  onSendMessage,
  isAiTyping,
}: ChatWindowProps) {
  const [inputText, setInputText] = useState("");
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [showImageAttachMenu, setShowImageAttachMenu] = useState(false);
  const [customImgUrl, setCustomImgUrl] = useState("");

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isAiTyping]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !attachedImage) return;

    onSendMessage(inputText.trim(), attachedImage || undefined);
    setInputText("");
    setAttachedImage(null);
  };

  // Predefined gorgeous imagery presets for instant chat attachment
  const CHAT_IMAGE_PRESETS = [
    "https://images.unsplash.com/photo-1501854140801-50d01698950b?w=400&h=300&fit=crop", // beautiful landscape
    "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=400&h=300&fit=crop", // foggy forest
    "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=400&h=300&fit=crop", // nature bridge
    "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop", // gourmet salad
    "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?w=400&h=300&fit=crop"  // beautiful starry night
  ];

  const handleAttachPresetImage = (url: string) => {
    setAttachedImage(url);
    setShowImageAttachMenu(false);
  };

  const handleCustomImageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (customImgUrl.trim()) {
      setAttachedImage(customImgUrl.trim());
      setCustomImgUrl("");
      setShowImageAttachMenu(false);
    }
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <section id="chat-window" className="flex-1 bg-[#050508] flex flex-col h-full overflow-hidden relative">
      
      {/* A. Chat Header */}
      <div className="h-16 border-b border-white/5 bg-[#050508]/80 backdrop-blur-md px-6 flex items-center justify-between shadow-sm shrink-0 z-10">
        <div className="flex items-center gap-3">
          {isDm && activeDmUser ? (
            <div className="relative">
              <img src={activeDmUser.avatar} alt={roomName} className="w-10 h-10 rounded-full object-cover border border-white/10" referrerPolicy="no-referrer" />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border border-[#050508] rounded-full animate-pulse" />
            </div>
          ) : (
            <div className="w-10 h-10 rounded-full bg-cyan-500/10 flex items-center justify-center text-cyan-400 border border-cyan-500/20 text-lg">
              🌍
            </div>
          )}
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white tracking-tight">{roomName}</h2>
              {isDm && activeDmUser?.isAi && (
                <span className="text-[8px] bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 px-1 py-0.5 rounded font-mono uppercase font-bold tracking-wider">
                  ACTIVE NODE
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 truncate max-w-md">{roomDesc}</p>
          </div>
        </div>
      </div>

      {/* B. Messaging Canvas */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-[#050508]">
        
        {/* Message Thread */}
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-2 opacity-50 p-6">
            <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-3xl">💬</div>
            <h3 className="text-sm font-semibold text-slate-300">No Messages Yet</h3>
            <p className="text-xs text-slate-500 max-w-xs">Type a message below to start chatting. Everything is fast, encrypted, and completely secure.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {messages.map((msg) => {
              const isMe = msg.senderId === userProfile?.id;
              
              return (
                <div 
                  id={`message-row-${msg.id}`}
                  key={msg.id} 
                  className={`flex gap-3 max-w-lg ${isMe ? "ml-auto flex-row-reverse" : "mr-auto"}`}
                >
                  {/* Avatar */}
                  {!isMe && (
                    <img 
                      src={msg.senderAvatar} 
                      alt={msg.senderName} 
                      className="w-8 h-8 rounded-full object-cover mt-0.5 border border-white/10" 
                      referrerPolicy="no-referrer"
                    />
                  )}

                  {/* Bubble Container */}
                  <div className="space-y-0.5">
                    {/* Name block on public lobbies */}
                    {!isMe && !isDm && (
                      <p className="text-[10px] font-semibold text-slate-400 pl-2">{msg.senderName}</p>
                    )}

                    {/* Bubble body */}
                    <div className={`p-4 rounded-2xl relative shadow-sm ${
                      isMe 
                        ? "bg-cyan-600 text-white rounded-tr-none shadow-[0_0_10px_rgba(8,145,178,0.3)] shadow-lg" 
                        : "bg-white/5 text-slate-200 border border-white/10 rounded-tl-none"
                    }`}>
                      
                      {/* Optional attached image */}
                      {msg.text.startsWith("[IMG]") ? (
                        <div className="rounded-lg overflow-hidden mb-2 max-w-xs border border-white/5">
                          <img 
                            src={msg.text.replace("[IMG]", "")} 
                            alt="Chat attachment" 
                            className="w-full h-auto object-cover max-h-60" 
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      ) : (
                        <p className="text-sm leading-relaxed break-words whitespace-pre-wrap">{msg.text}</p>
                      )}

                      {/* Info & Checkmarks */}
                      <div className="flex items-center justify-end gap-1.5 mt-1.5 text-[9px] opacity-70">
                        <span className="font-mono">{formatTime(msg.timestamp)}</span>
                        
                        {isMe && (
                          <span className="shrink-0">
                            {msg.status === "sent" ? (
                              <Check size={11} className="text-slate-300" />
                            ) : msg.status === "delivered" ? (
                              <CheckCheck size={11} className="text-slate-300" />
                            ) : (
                              <CheckCheck size={11} className="text-cyan-300" />
                            )}
                          </span>
                        )}
                      </div>

                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Simulated Typing Indicator */}
        {isAiTyping && (
          <div className="flex gap-3 max-w-lg mr-auto animate-pulse">
            <img 
              src={activeDmUser?.avatar || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&h=120&fit=crop"} 
              alt="Typing avatar" 
              className="w-8 h-8 rounded-full object-cover border border-white/10" 
              referrerPolicy="no-referrer"
            />
            <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-none px-4 py-2.5 flex items-center gap-1">
              <span className="text-xs text-slate-400 font-medium italic">{activeDmUser?.name || "Someone"} is writing</span>
              <span className="flex gap-1 items-center ml-1">
                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce delay-0" />
                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce delay-150" />
                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce delay-300" />
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* D. Bottom Input Area */}
      <div className="p-4 border-t border-white/5 bg-[#050508] shrink-0">
        
        {/* Attachment Thumbnail Preview */}
        {attachedImage && (
          <div className="mb-3 p-2 bg-white/5 border border-white/10 rounded-xl flex items-center justify-between animate-fade-in">
            <div className="flex items-center gap-2">
              <img src={attachedImage} alt="Attachment thumbnail" className="w-12 h-12 rounded object-cover border border-white/10" referrerPolicy="no-referrer" />
              <div className="text-left">
                <p className="text-xs font-semibold text-slate-300">Photo Attached</p>
                <p className="text-[10px] text-slate-500 truncate max-w-xs">{attachedImage}</p>
              </div>
            </div>
            <button 
              id="clear-attachment-btn"
              type="button"
              onClick={() => setAttachedImage(null)} 
              className="text-red-400 hover:text-red-300 text-xs font-medium px-2.5 py-1 bg-red-950/20 border border-red-950 rounded-lg cursor-pointer transition-colors"
            >
              Remove
            </button>
          </div>
        )}

        <form onSubmit={handleSend} className="flex gap-2">
          
          {/* Picture Attach Button Trigger */}
          <button
            id="toggle-image-attach-menu-btn"
            type="button"
            onClick={() => setShowImageAttachMenu(!showImageAttachMenu)}
            className={`p-2.5 rounded-lg border flex items-center justify-center transition-colors cursor-pointer ${
              showImageAttachMenu 
                ? "bg-cyan-500/10 border-cyan-500/50 text-cyan-400" 
                : "bg-white/5 border-white/10 text-slate-400 hover:text-slate-200"
            }`}
            title="Attach picture"
          >
            <Image size={20} />
          </button>

          {/* Text Input Field */}
          <input
            id="chat-message-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={isDm ? `Text ${roomName}...` : "Type a message to post globally..."}
            className="flex-1 bg-white/5 border border-white/10 text-slate-100 placeholder-slate-500 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500 transition-colors"
          />

          {/* Submit Trigger */}
          <button
            id="send-chat-message-btn"
            type="submit"
            disabled={!inputText.trim() && !attachedImage}
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium p-2.5 rounded-lg flex items-center justify-center transition-colors disabled:opacity-40 disabled:hover:bg-cyan-600 shrink-0 cursor-pointer"
          >
            <Send size={18} />
          </button>
        </form>

        {/* Photo Attachment Picker Panel Overlay */}
        {showImageAttachMenu && (
          <div id="image-attach-panel" className="absolute bottom-16 left-4 bg-[#08090C] border border-white/10 rounded-xl p-4 shadow-2xl w-80 animate-fade-in z-20">
            <div className="flex justify-between items-center mb-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-widest">Attach a Photo</h4>
              <button 
                id="close-image-attach-menu-btn"
                type="button"
                onClick={() => setShowImageAttachMenu(false)} 
                className="text-slate-500 hover:text-slate-300 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>
            
            <p className="text-[11px] text-slate-500 mb-2">Select from these elegant presets:</p>
            <div className="grid grid-cols-5 gap-1.5 mb-3">
              {CHAT_IMAGE_PRESETS.map((url, idx) => (
                <button
                  id={`chat-image-preset-btn-${idx}`}
                  key={idx}
                  type="button"
                  onClick={() => handleAttachPresetImage(url)}
                  className="rounded overflow-hidden border border-white/10 aspect-square cursor-pointer hover:scale-105 transition-transform"
                >
                  <img src={url} alt={`Preset ${idx}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>

            <div className="border-t border-white/10 pt-3">
              <p className="text-[11px] text-slate-500 mb-2">Or paste any image web URL:</p>
              <form onSubmit={handleCustomImageSubmit} className="flex gap-1.5">
                <input
                  id="custom-attachment-url-input"
                  type="url"
                  placeholder="https://example.com/pic.png"
                  value={customImgUrl}
                  onChange={(e) => setCustomImgUrl(e.target.value)}
                  className="flex-1 bg-[#050508] border border-white/10 text-xs rounded text-slate-200 px-2 py-1.5 focus:outline-none focus:border-cyan-500"
                />
                <button
                  id="submit-custom-attachment-btn"
                  type="submit"
                  className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs rounded px-2.5 py-1 transition-colors cursor-pointer"
                >
                  Apply
                </button>
              </form>
            </div>
          </div>
        )}

      </div>

    </section>
  );
}
