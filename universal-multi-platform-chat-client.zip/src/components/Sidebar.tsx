import React, { useState } from "react";
import { Globe, Settings, Edit, Check, Globe2, MessageSquare, ShieldCheck } from "lucide-react";
import { Room, UserProfile } from "../types";
import AvatarPicker from "./AvatarPicker";

interface SidebarProps {
  userProfile: UserProfile | null;
  onUpdateProfile: (name: string, avatar: string, bio: string) => void;
  rooms: Room[];
  activeRoomId: string;
  onSelectRoom: (roomId: string) => void;
  onlineUsers: UserProfile[];
}

export default function Sidebar({
  userProfile,
  onUpdateProfile,
  rooms,
  activeRoomId,
  onSelectRoom,
  onlineUsers,
}: SidebarProps) {
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  
  // Edit Profile States
  const [editName, setEditName] = useState("");
  const [editBio, setEditBio] = useState("");
  const [editAvatar, setEditAvatar] = useState("");

  const handleStartEdit = () => {
    if (userProfile) {
      setEditName(userProfile.name);
      setEditBio(userProfile.bio);
      setEditAvatar(userProfile.avatar);
      setIsEditingProfile(true);
    }
  };

  const handleSaveProfile = () => {
    if (editName.trim()) {
      onUpdateProfile(editName.trim(), editAvatar, editBio.trim());
      setIsEditingProfile(false);
    }
  };

  // Helper to determine the DM room id between the current user and another user
  const getDmRoomId = (otherId: string) => {
    if (!userProfile) return "";
    const sorted = [userProfile.id, otherId].sort();
    return `dm_${sorted[0]}_${sorted[1]}`;
  };

  return (
    <aside id="app-sidebar" className="w-80 bg-[#08090C] border-r border-white/5 flex flex-col h-full overflow-hidden shrink-0">
      
      {/* 1. Header / Profile Area */}
      <div className="p-4 border-b border-white/5 bg-[#08090C]/80">
        <div className="flex items-center gap-2 mb-4">
          <Globe2 className="text-cyan-400 animate-pulse shrink-0" size={24} />
          <h1 className="text-lg font-bold text-white tracking-tight">OmniBridge</h1>
          <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-semibold px-2 py-0.5 rounded-full ml-auto">
            FAST SECURE
          </span>
        </div>

        {userProfile ? (
          <div className="bg-white/5 border border-white/10 rounded-xl p-3 relative">
            {isEditingProfile ? (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <button 
                    id="trigger-avatar-picker"
                    type="button"
                    onClick={() => setShowAvatarPicker(true)} 
                    className="relative rounded-full overflow-hidden group cursor-pointer w-12 h-12 border-2 border-dashed border-cyan-500 hover:border-solid transition-all"
                  >
                    <img src={editAvatar || userProfile.avatar} alt="Editing avatar" className="w-full h-full object-cover opacity-60" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-[10px] text-white font-medium">Change</div>
                  </button>
                  <input
                    id="edit-profile-name-input"
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="flex-1 bg-[#050508] border border-white/10 rounded px-2 py-1 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                    placeholder="Nickname"
                  />
                </div>
                <input
                  id="edit-profile-bio-input"
                  type="text"
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full bg-[#050508] border border-white/10 rounded px-2 py-1 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                  placeholder="Bio status"
                />
                <div className="flex justify-end gap-1.5">
                  <button
                    id="cancel-profile-edit-btn"
                    type="button"
                    onClick={() => setIsEditingProfile(false)}
                    className="px-2.5 py-1 rounded text-xs text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    id="save-profile-edit-btn"
                    type="button"
                    onClick={handleSaveProfile}
                    className="px-2.5 py-1 bg-cyan-600 hover:bg-cyan-500 rounded text-xs text-white font-medium flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Check size={12} /> Save
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div className="relative shrink-0">
                  <img src={userProfile.avatar} alt="Profile" className="w-11 h-11 rounded-full object-cover border border-white/10" referrerPolicy="no-referrer" />
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-[#08090C] rounded-full"></span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h2 className="text-sm font-semibold text-white truncate">{userProfile.name}</h2>
                    <button 
                      id="start-profile-edit-btn"
                      type="button"
                      onClick={handleStartEdit} 
                      className="text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer"
                    >
                      <Edit size={12} />
                    </button>
                  </div>
                  <p className="text-[10px] text-cyan-400 font-mono truncate">{userProfile.id} • Hashed Node</p>
                  <p className="text-[11px] text-slate-400 truncate italic mt-0.5">"{userProfile.bio}"</p>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="h-14 bg-white/5 animate-pulse rounded-xl" />
        )}
      </div>

      {/* 2. Navigation List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-5">
        
        {/* A. Global Rooms */}
        <div>
          <div className="flex items-center justify-between px-2 mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">🌍 Global Lobbies</span>
          </div>
          <div className="space-y-1">
            {rooms.map((room) => {
              const isActive = activeRoomId === room.id;
              return (
                <button
                  id={`room-item-btn-${room.id}`}
                  key={room.id}
                  type="button"
                  onClick={() => onSelectRoom(room.id)}
                  className={`w-full text-left p-2.5 rounded-xl flex items-center gap-3 transition-all cursor-pointer ${
                    isActive 
                      ? "bg-cyan-500/10 border border-cyan-500/20 text-white shadow-sm shadow-[0_0_15px_rgba(34,211,238,0.1)]" 
                      : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                  }`}
                >
                  <Globe size={16} className={isActive ? "text-cyan-400" : "text-slate-500"} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{room.name}</p>
                    <p className="text-[11px] text-slate-500 truncate">{room.desc}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* B. Worldwide Active Nodes / DMs */}
        <div>
          <div className="flex items-center justify-between px-2 mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">👥 Worldwide Active Nodes</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-mono">
              {onlineUsers.length} ONLINE
            </span>
          </div>

          {onlineUsers.length === 0 ? (
            <div className="border border-dashed border-white/10 rounded-xl p-4 text-center">
              <p className="text-xs text-slate-500">Scanning for other active nodes...</p>
            </div>
          ) : (
            <div className="space-y-1">
              {onlineUsers.map((user) => {
                const targetRoomId = getDmRoomId(user.id);
                const isActive = activeRoomId === targetRoomId;
                return (
                  <button
                    id={`user-item-btn-${user.id}`}
                    key={user.id}
                    type="button"
                    onClick={() => onSelectRoom(targetRoomId)}
                    className={`w-full text-left p-2.5 rounded-xl flex items-center gap-3 transition-all cursor-pointer ${
                      isActive 
                        ? "bg-cyan-500/10 border border-cyan-500/20 text-white shadow-sm shadow-[0_0_15px_rgba(34,211,238,0.1)]" 
                        : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover border border-white/10" referrerPolicy="no-referrer" />
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border border-[#08090C] rounded-full animate-pulse" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <p className="text-sm font-semibold text-white truncate">{user.name}</p>
                        {user.isAi && (
                          <span className="text-[8px] bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 px-1 py-0.5 rounded font-mono uppercase font-bold tracking-wider">
                            NODE
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 truncate italic">"{user.bio || 'Secure Node Visitor'}"</p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

      </div>

      {/* 3. Footer Banner - Privacy assurance */}
      <div className="p-3 bg-[#08090C]/40 border-t border-white/5 text-center text-[10px] text-slate-500 font-mono">
        🛡️ End-to-End Encrypted Tunnel • Hashed IP Address
      </div>

      {/* 4. Modals */}
      {showAvatarPicker && (
        <AvatarPicker
          currentAvatar={editAvatar || (userProfile?.avatar || "")}
          onSelect={(url) => setEditAvatar(url)}
          onClose={() => setShowAvatarPicker(false)}
        />
      )}

    </aside>
  );
}
